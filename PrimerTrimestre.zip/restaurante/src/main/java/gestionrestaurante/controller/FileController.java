package gestionrestaurante.controller;


import gestionrestaurante.service.FileService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@RestController
@RequestMapping("/api/files")
public class FileController {

    private final FileService fileService;

    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    @PostMapping("/import")
    public ResponseEntity<String> importarRestaurantes(@RequestParam("file") MultipartFile file) {
        try {
            fileService.importarRestaurantesDesdeCSV(file);
            return ResponseEntity.ok("Restaurantes importados correctamente.");
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al procesar el archivo.");
        }
    }

    @GetMapping("/export")
    public ResponseEntity<byte[]> exportarReseñas(@RequestParam String ciudad) {
        try {
            File file = fileService.exportarReseñasPorCiudad(ciudad);
            byte[] contenido = Files.readAllBytes(file.toPath());

            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + file.getName());

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(contenido);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}

