package gestionrestaurante.repository;

import gestionrestaurante.model.Reseña;

import java.util.Arrays;
import java.util.List;

public class ReseñaRepository {
    public List<Reseña> findByUsuario(String usuario) {
        return List.of();
    }

    public Reseña save(Reseña reseña) {
        return reseña;
    }

    public Arrays findAll() {
        return null;
    }
}
