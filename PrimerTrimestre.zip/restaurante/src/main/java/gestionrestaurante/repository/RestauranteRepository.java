package gestionrestaurante.repository;

import gestionrestaurante.model.Restaurante;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface RestauranteRepository extends MongoRepository<Restaurante, String> {
    List<Restaurante> findByCiudad(String ciudad); // Obtener restaurantes por ciudad
}
