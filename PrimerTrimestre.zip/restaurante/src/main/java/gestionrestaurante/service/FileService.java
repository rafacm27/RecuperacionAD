package gestionrestaurante.service;

import gestionrestaurante.model.Restaurante;
import gestionrestaurante.model.Reseña;
import gestionrestaurante.repository.RestauranteRepository;
import gestionrestaurante.repository.ReseñaRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Arrays.stream;

@Service
public class FileService {

    private final RestauranteRepository restauranteRepository;
    private final ReseñaRepository reseñaRepository;

    public FileService(RestauranteRepository restauranteRepository, ReseñaRepository reseñaRepository) {
        this.restauranteRepository = restauranteRepository;
        this.reseñaRepository = reseñaRepository;
    }

    public void importarRestaurantesDesdeCSV(MultipartFile file) throws IOException {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length >= 2) {
                    Restaurante restaurante = new Restaurante();
                    restaurante.setNombre(datos[0]);
                    restaurante.setCiudad(datos[1]);
                    restauranteRepository.save(restaurante);
                }
            }
        }
    }

    public File exportarReseñasPorCiudad(String ciudad) throws IOException {
        List<Reseña> reseñas = reseñaRepository.findAll().stream()
                .filter(r -> r.getRestaurante().getCiudad().equalsIgnoreCase(ciudad))
                .collect(Collectors.toList());

        Path archivo = Files.createTempFile("reseñas_" + ciudad, ".csv");
        try (BufferedWriter writer = Files.newBufferedWriter(archivo, StandardOpenOption.WRITE)) {
            writer.write("Restaurante,Usuario,Comentario,Valoración\n");
            for (Reseña reseña : reseñas) {
                writer.write(reseña.getRestaurante().getNombre() + ","
                        + reseña.getUsuario() + ","
                        + reseña.getComentario() + ","
                        + reseña.getValoracion() + "\n");
            }
        }
        return archivo.toFile();
    }
}

