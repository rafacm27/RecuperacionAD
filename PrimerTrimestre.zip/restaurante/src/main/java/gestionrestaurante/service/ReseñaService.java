package gestionrestaurante.service;

import gestionrestaurante.model.Reseña;
import gestionrestaurante.repository.ReseñaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReseñaService {

    @Autowired
    private ReseñaRepository reseñaRepository;

    public List<Reseña> obtenerReseñasPorUsuario(String usuario) {
        return reseñaRepository.findByUsuario(usuario);
    }

    public Reseña guardarReseña(Reseña reseña) {
        return reseñaRepository.save(reseña);
    }
}
