package gestionrestaurante.service;

import gestionrestaurante.model.Restaurante;
import gestionrestaurante.repository.RestauranteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataService {
    @Autowired
    private RestauranteRepository restauranteRepo;

    public Restaurante guardarRestaurante(Restaurante restaurante) {
        return restauranteRepo.save(restaurante);
    }
}

