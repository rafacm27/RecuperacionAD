package gestionrestaurante.model;

import jakarta.persistence.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "restaurantes")
public class Restaurante {
    @Id
    private String id;
    private String nombre;
    private String ciudad;
    private List<Reseña> reseñas = new ArrayList<>();

    public void setNombre(String dato) {
    }

    public void setCiudad(String dato) {
    }
}

