package gestionrestaurante.model;

public class Reseña {
    private String comentario;
    private String usuario;
    private int valoracion;

    public Object getUsuario() {
        return null;
    }

    public Object getComentario() {
        return null;
    }

    public Object getValoracion() {
        return null;
    }

    public Object getRestaurante() {
        return null;
    }
}
